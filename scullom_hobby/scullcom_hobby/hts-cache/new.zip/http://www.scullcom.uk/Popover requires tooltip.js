<!doctype html>
<!--[if !IE]>
<html class="no-js non-ie" lang="en-GB"> <![endif]-->
<!--[if IE 7 ]>
<html class="no-js ie7" lang="en-GB"> <![endif]-->
<!--[if IE 8 ]>
<html class="no-js ie8" lang="en-GB"> <![endif]-->
<!--[if IE 9 ]>
<html class="no-js ie9" lang="en-GB"> <![endif]-->
<!--[if gt IE 9]><!-->
<html class="no-js" lang="en-GB"> <!--<![endif]-->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="">
<link rel="profile" href="http://gmpg.org/xfn/11">

<title>Page not found &#8211; Scullcom</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Scullcom &raquo; Feed" href="http://www.scullcom.uk/feed/" />
<link rel="alternate" type="application/rss+xml" title="Scullcom &raquo; Comments Feed" href="http://www.scullcom.uk/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.4\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.scullcom.uk\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.3"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='apss-font-awesome-css'  href='http://www.scullcom.uk/wp-content/plugins/accesspress-social-share/css/font-awesome/font-awesome.min.css?ver=4.3.5' type='text/css' media='all' />
<link rel='stylesheet' id='apss-font-opensans-css'  href='//fonts.googleapis.com/css?family=Open+Sans&#038;ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='apss-frontend-css-css'  href='http://www.scullcom.uk/wp-content/plugins/accesspress-social-share/css/frontend.css?ver=4.3.5' type='text/css' media='all' />
<link rel='stylesheet' id='ye_dynamic-css'  href='http://www.scullcom.uk/wp-content/plugins/youtube-embed/css/main.min.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='sparkling-bootstrap-css'  href='http://www.scullcom.uk/wp-content/themes/sparkling/assets/css/bootstrap.min.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='sparkling-icons-css'  href='http://www.scullcom.uk/wp-content/themes/sparkling/assets/css/font-awesome.min.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='sparkling-fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A400italic%2C400%2C600%2C700%7CRoboto+Slab%3A400%2C300%2C700&#038;ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='sparkling-style-css'  href='http://www.scullcom.uk/wp-content/themes/sparkling/style.css?ver=4.9.3' type='text/css' media='all' />
<script type='text/javascript' src='http://www.scullcom.uk/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-content/themes/sparkling/assets/js/vendor/modernizr.min.js?ver=4.9.3'></script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-content/themes/sparkling/assets/js/vendor/bootstrap.min.js?ver=4.9.3'></script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-content/themes/sparkling/assets/js/functions.min.js?ver=4.9.3'></script>
<link rel='https://api.w.org/' href='http://www.scullcom.uk/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.scullcom.uk/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.scullcom.uk/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.3" />
<link rel="apple-touch-icon" sizes="57x57" href="/wp-content/uploads/fbrfg/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/wp-content/uploads/fbrfg/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/wp-content/uploads/fbrfg/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/wp-content/uploads/fbrfg/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/wp-content/uploads/fbrfg/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/wp-content/uploads/fbrfg/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/wp-content/uploads/fbrfg/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/wp-content/uploads/fbrfg/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/wp-content/uploads/fbrfg/apple-touch-icon-180x180.png">
<link rel="icon" type="image/png" href="/wp-content/uploads/fbrfg/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="/wp-content/uploads/fbrfg/favicon-194x194.png" sizes="194x194">
<link rel="icon" type="image/png" href="/wp-content/uploads/fbrfg/favicon-96x96.png" sizes="96x96">
<link rel="icon" type="image/png" href="/wp-content/uploads/fbrfg/android-chrome-192x192.png" sizes="192x192">
<link rel="icon" type="image/png" href="/wp-content/uploads/fbrfg/favicon-16x16.png" sizes="16x16">
<link rel="manifest" href="/wp-content/uploads/fbrfg/manifest.json">
<link rel="mask-icon" href="/wp-content/uploads/fbrfg/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="/wp-content/uploads/fbrfg/favicon.ico">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-TileImage" content="/wp-content/uploads/fbrfg/mstile-144x144.png">
<meta name="msapplication-config" content="/wp-content/uploads/fbrfg/browserconfig.xml">
<meta name="theme-color" content="#ffffff"><style type="text/css"></style>		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		
</head>

<body class="error404 group-blog">
<a class="sr-only sr-only-focusable" href="#content">Skip to main content</a>
<div id="page" class="hfeed site">

	<header id="masthead" class="site-header" role="banner">
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="container">
				<div class="row">
					<div class="site-navigation-inner col-sm-12">
						<div class="navbar-header">
							<button type="button" class="btn navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>

														<div id="logo">
																																<a href="http://www.scullcom.uk/"><img src="http://www.scullcom.uk/wp-content/uploads/2016/03/logo_grey2.png"  height="76" width="300" alt="Scullcom"/></a>
																																</div><!-- end of #logo -->
						</div>
						<div class="collapse navbar-collapse navbar-ex1-collapse"><ul id="menu-main-menu" class="nav navbar-nav"><li id="menu-item-32" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-32"><a href="http://www.scullcom.uk/">Home</a></li>
<li id="menu-item-36" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-36 dropdown"><a href="http://www.scullcom.uk/category/projects/">Projects </a><span class="caret sparkling-dropdown"></span>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-208" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-208"><a href="http://www.scullcom.uk/category/projects/">All Projects</a></li>
	<li id="menu-item-201" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-201"><a href="http://www.scullcom.uk/category/projects/5-volt-precision-reference/">5 Volt Precision Reference</a></li>
	<li id="menu-item-468" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-468"><a href="http://www.scullcom.uk/category/projects/constant-current-source-box/">Constant Current Source Box</a></li>
	<li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="http://www.scullcom.uk/category/projects/dc-load/">DC Load</a></li>
	<li id="menu-item-469" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-469"><a href="http://www.scullcom.uk/category/projects/dc-voltage-calibrator/">DC Voltage Calibrator</a></li>
	<li id="menu-item-203" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-203"><a href="http://www.scullcom.uk/category/projects/diy-pcb-exposure-unit/">DIY PCB Exposure Unit</a></li>
	<li id="menu-item-199" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-199"><a href="http://www.scullcom.uk/category/projects/frequency-reference/">Frequency Reference</a></li>
	<li id="menu-item-200" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-200"><a href="http://www.scullcom.uk/category/projects/function-generator/">Function Generator</a></li>
	<li id="menu-item-502" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-502"><a href="http://www.scullcom.uk/category/projects/function-generator-mk2/">Function Generator Mk2</a></li>
	<li id="menu-item-204" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-204"><a href="http://www.scullcom.uk/category/projects/gps-system/">GPS System</a></li>
	<li id="menu-item-205" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-205"><a href="http://www.scullcom.uk/category/projects/led-floodlight/">LED Floodlight</a></li>
	<li id="menu-item-470" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-470"><a href="http://www.scullcom.uk/category/projects/low-current-reference/">Low Current Reference</a></li>
	<li id="menu-item-202" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-202"><a href="http://www.scullcom.uk/category/projects/milliohm-meter/">Milliohm Meter</a></li>
	<li id="menu-item-198" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-198"><a href="http://www.scullcom.uk/category/projects/millivolt-meter/">Millivolt Meter</a></li>
	<li id="menu-item-207" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-207"><a href="http://www.scullcom.uk/category/projects/precision-voltage-reference-box/">Precision Voltage Reference Box</a></li>
	<li id="menu-item-355" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-355"><a href="http://www.scullcom.uk/category/projects/stair-step-waveform-generator/">Stair-Step Waveform Generator</a></li>
	<li id="menu-item-389" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-389"><a href="http://www.scullcom.uk/category/projects/pulse-generator/">Pulse Generator</a></li>
</ul>
</li>
<li id="menu-item-38" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-38"><a href="http://www.scullcom.uk/category/reviews/">Reviews</a></li>
<li id="menu-item-37" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-37"><a href="http://www.scullcom.uk/category/teardowns/">Teardowns</a></li>
<li id="menu-item-132" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-132"><a href="http://www.scullcom.uk/category/tutorials/">Tutorials</a></li>
<li id="menu-item-210" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-210 dropdown"><a href="http://www.scullcom.uk/category/basics/">Basics </a><span class="caret sparkling-dropdown"></span>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-218" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-218"><a href="http://www.scullcom.uk/category/basics/resistor/">Resistor</a></li>
	<li id="menu-item-219" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-219"><a href="http://www.scullcom.uk/category/basics/capacitor/">Capacitor</a></li>
	<li id="menu-item-221" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-221"><a href="http://www.scullcom.uk/category/basics/inductor/">Inductor</a></li>
	<li id="menu-item-220" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-220"><a href="http://www.scullcom.uk/category/basics/diode/">Diode</a></li>
	<li id="menu-item-245" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-245"><a href="http://www.scullcom.uk/category/basics/opto/">Opto</a></li>
	<li id="menu-item-222" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-222"><a href="http://www.scullcom.uk/category/basics/transistor/">Transistor</a></li>
	<li id="menu-item-223" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-223"><a href="http://www.scullcom.uk/category/basics/op-amp/">OP Amp</a></li>
	<li id="menu-item-224" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-224"><a href="http://www.scullcom.uk/category/basics/logic-gates/">Logic Gates</a></li>
	<li id="menu-item-243" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-243"><a href="http://www.scullcom.uk/category/basics/filters/">Filters</a></li>
	<li id="menu-item-246" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-246"><a href="http://www.scullcom.uk/category/basics/sensors/">Sensors</a></li>
	<li id="menu-item-244" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-244"><a href="http://www.scullcom.uk/category/basics/fuses/">Fuses</a></li>
	<li id="menu-item-242" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-242"><a href="http://www.scullcom.uk/category/basics/batteries/">Batteries</a></li>
	<li id="menu-item-247" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-247"><a href="http://www.scullcom.uk/category/basics/transformer/">Transformer</a></li>
	<li id="menu-item-241" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-241"><a href="http://www.scullcom.uk/category/basics/antenna/">Antenna</a></li>
</ul>
</li>
<li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a href="http://www.scullcom.uk/about/">About</a></li>
</ul></div>					</div>
				</div>
			</div>
		</nav><!-- .site-navigation -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">

		<div class="top-section">
								</div>

		<div class="container main-content-area">
						<div class="row side-pull-left">
				<div class="main-content-inner col-sm-12 col-md-8">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="post-inner-content">

				<section class="error-404 not-found">
					<header class="page-header">
						<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
					</header><!-- .page-header -->

					<div class="page-content">
						<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

						
<form role="search" method="get" class="form-search" action="http://www.scullcom.uk/">
  <div class="input-group">
	  <label class="screen-reader-text" for="s">Search for:</label>
	<input type="text" class="form-control search-query" placeholder="Search&hellip;" value="" name="s" title="Search for:" />
	<span class="input-group-btn">
	  <button type="submit" class="btn btn-default" name="submit" id="searchsubmit" value="Search"><span class="glyphicon glyphicon-search"></span></button>
	</span>
  </div>
</form>

						<div class="row">
							<div class="col-md-6 not-found-widget">
										<div class="widget widget_recent_entries">		<h2 class="widgettitle">Recent Posts</h2>		<ul>
											<li>
					<a href="http://www.scullcom.uk/function-generator-mk2/">Function Generator Mk2</a>
									</li>
											<li>
					<a href="http://www.scullcom.uk/dc-voltage-calibrator/">DC Voltage Calibrator</a>
									</li>
											<li>
					<a href="http://www.scullcom.uk/build-a-sinclair-zx80-clone/">Build a Sinclair ZX80 Clone</a>
									</li>
											<li>
					<a href="http://www.scullcom.uk/design-build-an-electronic-dc-load-part-1/">Design &#038; Build an Electronic DC Load</a>
									</li>
											<li>
					<a href="http://www.scullcom.uk/millivolt-meter-mk2/">Millivolt Meter MK2</a>
									</li>
					</ul>
		</div>							</div>

							<div class="col-md-6 not-found-widget">
																<div class="widget widget_categories">
									<h2 class="widgettitle">Most Used Categories</h2>
									<ul>
										<li class="cat-item cat-item-5"><a href="http://www.scullcom.uk/category/projects/" >Projects</a> (30)
<ul class='children'>
	<li class="cat-item cat-item-9"><a href="http://www.scullcom.uk/category/projects/millivolt-meter/" >Millivolt Meter</a> (5)
</li>
	<li class="cat-item cat-item-4"><a href="http://www.scullcom.uk/category/projects/frequency-reference/" >Frequency Reference</a> (4)
</li>
	<li class="cat-item cat-item-10"><a href="http://www.scullcom.uk/category/projects/function-generator/" >Function Generator</a> (3)
</li>
	<li class="cat-item cat-item-12"><a href="http://www.scullcom.uk/category/projects/5-volt-precision-reference/" >5 Volt Precision Reference</a> (3)
</li>
	<li class="cat-item cat-item-8"><a href="http://www.scullcom.uk/category/projects/milliohm-meter/" >Milliohm Meter</a> (2)
</li>
</ul>
</li>
	<li class="cat-item cat-item-6"><a href="http://www.scullcom.uk/category/teardowns/" >Teardowns</a> (14)
</li>
	<li class="cat-item cat-item-7"><a href="http://www.scullcom.uk/category/reviews/" >Reviews</a> (12)
</li>
	<li class="cat-item cat-item-18"><a href="http://www.scullcom.uk/category/basics/" >Basics</a> (2)
</li>
	<li class="cat-item cat-item-1"><a href="http://www.scullcom.uk/category/uncategorised/" >Uncategorised</a> (1)
</li>
									</ul>
								</div><!-- .widget -->
															</div>
						</div>

						<div class="row">
							<div class="col-md-6 not-found-widget">
								<div class="widget widget_archive"><h2 class="widgettitle">Archives</h2><p>Try looking in the monthly archives. 🙂</p>		<label class="screen-reader-text" for="archives-dropdown--1">Archives</label>
		<select id="archives-dropdown--1" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
			
			<option value="">Select Month</option>
				<option value='http://www.scullcom.uk/2018/08/'> August 2018 </option>
	<option value='http://www.scullcom.uk/2017/12/'> December 2017 </option>
	<option value='http://www.scullcom.uk/2017/06/'> June 2017 </option>
	<option value='http://www.scullcom.uk/2016/12/'> December 2016 </option>
	<option value='http://www.scullcom.uk/2016/11/'> November 2016 </option>
	<option value='http://www.scullcom.uk/2016/09/'> September 2016 </option>
	<option value='http://www.scullcom.uk/2016/06/'> June 2016 </option>
	<option value='http://www.scullcom.uk/2016/05/'> May 2016 </option>
	<option value='http://www.scullcom.uk/2016/03/'> March 2016 </option>
	<option value='http://www.scullcom.uk/2016/02/'> February 2016 </option>
	<option value='http://www.scullcom.uk/2016/01/'> January 2016 </option>
	<option value='http://www.scullcom.uk/2015/12/'> December 2015 </option>
	<option value='http://www.scullcom.uk/2015/10/'> October 2015 </option>
	<option value='http://www.scullcom.uk/2015/09/'> September 2015 </option>
	<option value='http://www.scullcom.uk/2015/08/'> August 2015 </option>
	<option value='http://www.scullcom.uk/2015/07/'> July 2015 </option>
	<option value='http://www.scullcom.uk/2015/05/'> May 2015 </option>
	<option value='http://www.scullcom.uk/2015/04/'> April 2015 </option>
	<option value='http://www.scullcom.uk/2015/03/'> March 2015 </option>
	<option value='http://www.scullcom.uk/2015/02/'> February 2015 </option>

		</select>
		</div>							</div>

							<div class="col-md-6 not-found-widget">
															</div>
						</div>


				</section><!-- .error-404 -->
			</div>
		</main><!-- #main -->
</div>

</div><!-- close .main-content-inner -->
<div id="secondary" class="widget-area col-sm-12 col-md-4" role="complementary">
	<div class="well">
							<aside id="youtubesubscribebuttonwidget-4" class="widget widget_youtubesubscribebuttonwidget">								<div class="g-ytsubscribe" data-channelid="UCDqryeq1kMDSEQwltWqASrA" data-layout="full" data-theme="default"></div>
<div id="youtubebuttcredit"></div>
<script type='text/javascript'>document.getElementById("youtubebuttcredit").style.display="none";window.___gcfg = {lang: 'en'};(function() {var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;po.src = 'https://apis.google.com/js/plusone.js';var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);})();</script>			</aside>		<aside id="search-2" class="widget widget_search">
<form role="search" method="get" class="form-search" action="http://www.scullcom.uk/">
  <div class="input-group">
	  <label class="screen-reader-text" for="s">Search for:</label>
	<input type="text" class="form-control search-query" placeholder="Search&hellip;" value="" name="s" title="Search for:" />
	<span class="input-group-btn">
	  <button type="submit" class="btn btn-default" name="submit" id="searchsubmit" value="Search"><span class="glyphicon glyphicon-search"></span></button>
	</span>
  </div>
</form>
</aside><aside id="categories-2" class="widget widget_categories"><h3 class="widget-title">Categories</h3>		<ul>
	<li class="cat-item cat-item-12"><a href="http://www.scullcom.uk/category/projects/5-volt-precision-reference/" >5 Volt Precision Reference</a>
</li>
	<li class="cat-item cat-item-18"><a href="http://www.scullcom.uk/category/basics/" >Basics</a>
</li>
	<li class="cat-item cat-item-14"><a href="http://www.scullcom.uk/category/projects/constant-current-source-box/" >Constant Current Source Box</a>
</li>
	<li class="cat-item cat-item-36"><a href="http://www.scullcom.uk/category/projects/dc-load/" >DC Load</a>
</li>
	<li class="cat-item cat-item-40"><a href="http://www.scullcom.uk/category/projects/dc-voltage-calibrator/" >DC Voltage Calibrator</a>
</li>
	<li class="cat-item cat-item-11"><a href="http://www.scullcom.uk/category/projects/diy-pcb-exposure-unit/" >DIY PCB Exposure Unit</a>
</li>
	<li class="cat-item cat-item-4"><a href="http://www.scullcom.uk/category/projects/frequency-reference/" >Frequency Reference</a>
</li>
	<li class="cat-item cat-item-10"><a href="http://www.scullcom.uk/category/projects/function-generator/" >Function Generator</a>
</li>
	<li class="cat-item cat-item-41"><a href="http://www.scullcom.uk/category/projects/function-generator-mk2/" >Function Generator Mk2</a>
</li>
	<li class="cat-item cat-item-15"><a href="http://www.scullcom.uk/category/projects/gps-system/" >GPS System</a>
</li>
	<li class="cat-item cat-item-16"><a href="http://www.scullcom.uk/category/projects/led-floodlight/" >LED Floodlight</a>
</li>
	<li class="cat-item cat-item-33"><a href="http://www.scullcom.uk/category/projects/low-current-reference/" >Low Current Reference</a>
</li>
	<li class="cat-item cat-item-8"><a href="http://www.scullcom.uk/category/projects/milliohm-meter/" >Milliohm Meter</a>
</li>
	<li class="cat-item cat-item-9"><a href="http://www.scullcom.uk/category/projects/millivolt-meter/" >Millivolt Meter</a>
</li>
	<li class="cat-item cat-item-24"><a href="http://www.scullcom.uk/category/basics/op-amp/" >OP Amp</a>
</li>
	<li class="cat-item cat-item-17"><a href="http://www.scullcom.uk/category/projects/precision-voltage-reference-box/" >Precision Voltage Reference Box</a>
</li>
	<li class="cat-item cat-item-5"><a href="http://www.scullcom.uk/category/projects/" >Projects</a>
</li>
	<li class="cat-item cat-item-35"><a href="http://www.scullcom.uk/category/projects/pulse-generator/" >Pulse Generator</a>
</li>
	<li class="cat-item cat-item-19"><a href="http://www.scullcom.uk/category/basics/resistor/" >Resistor</a>
</li>
	<li class="cat-item cat-item-7"><a href="http://www.scullcom.uk/category/reviews/" >Reviews</a>
</li>
	<li class="cat-item cat-item-34"><a href="http://www.scullcom.uk/category/projects/stair-step-waveform-generator/" >Stair-Step Waveform Generator</a>
</li>
	<li class="cat-item cat-item-6"><a href="http://www.scullcom.uk/category/teardowns/" >Teardowns</a>
</li>
	<li class="cat-item cat-item-13"><a href="http://www.scullcom.uk/category/tutorials/" >Tutorials</a>
</li>
	<li class="cat-item cat-item-1"><a href="http://www.scullcom.uk/category/uncategorised/" >Uncategorised</a>
</li>
	<li class="cat-item cat-item-39"><a href="http://www.scullcom.uk/category/projects/zx80/" >ZX80</a>
</li>
		</ul>
</aside><aside id="archives-2" class="widget widget_archive"><h3 class="widget-title">Archives</h3>		<ul>
			<li><a href='http://www.scullcom.uk/2018/08/'>August 2018</a></li>
	<li><a href='http://www.scullcom.uk/2017/12/'>December 2017</a></li>
	<li><a href='http://www.scullcom.uk/2017/06/'>June 2017</a></li>
	<li><a href='http://www.scullcom.uk/2016/12/'>December 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/11/'>November 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/09/'>September 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/06/'>June 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/05/'>May 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/03/'>March 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/02/'>February 2016</a></li>
	<li><a href='http://www.scullcom.uk/2016/01/'>January 2016</a></li>
	<li><a href='http://www.scullcom.uk/2015/12/'>December 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/10/'>October 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/09/'>September 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/08/'>August 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/07/'>July 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/05/'>May 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/04/'>April 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/03/'>March 2015</a></li>
	<li><a href='http://www.scullcom.uk/2015/02/'>February 2015</a></li>
		</ul>
		</aside><aside id="recent-comments-2" class="widget widget_recent_comments"><h3 class="widget-title">Recent Comments</h3><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link">james king</span> on <a href="http://www.scullcom.uk/design-build-an-electronic-dc-load-part-1/#comment-415">Design &#038; Build an Electronic DC Load</a></li><li class="recentcomments"><span class="comment-author-link">Cory Benjamin</span> on <a href="http://www.scullcom.uk/function-generator-mk2/#comment-414">Function Generator Mk2</a></li><li class="recentcomments"><span class="comment-author-link">Mark</span> on <a href="http://www.scullcom.uk/dc-voltage-calibrator/#comment-413">DC Voltage Calibrator</a></li><li class="recentcomments"><span class="comment-author-link">Patrick Ward</span> on <a href="http://www.scullcom.uk/design-build-an-electronic-dc-load-part-1/#comment-412">Design &#038; Build an Electronic DC Load</a></li><li class="recentcomments"><span class="comment-author-link">Lewis Bryant</span> on <a href="http://www.scullcom.uk/dc-voltage-calibrator/#comment-409">DC Voltage Calibrator</a></li></ul></aside><aside id="text-2" class="widget widget_text"><h3 class="widget-title">Meta</h3>			<div class="textwidget"><ul>
<li>
<a href="/wp-login.php">Log In</a>
</li>
<li>
<a href="/?feed=rss2">Posts RSS</a>
</li>
<li>
<a href="/?feed=comments-rss2">Posts RSS</a>
</li>
</ul></div>
		</aside>	</div>
</div><!-- #secondary -->
<!--WPFC_FOOTER_START-->		</div><!-- close .row -->
	</div><!-- close .container -->
</div><!-- close .site-content -->

	<div id="footer-area">
		<div class="container footer-inner">
			<div class="row">
				
				</div>
		</div>

		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="site-info container">
				<div class="row">
										<nav role="navigation" class="col-md-6">
											</nav>
					<div class="copyright col-md-6">
						Scullcom.uk all lefts reversed 						Theme by <a href="http://colorlib.com/" target="_blank">Colorlib</a> Powered by <a href="http://wordpress.org/" target="_blank">WordPress</a>					</div>
				</div>
			</div><!-- .site-info -->
			<div class="scroll-to-top"><i class="fa fa-angle-up"></i></div><!-- .scroll-to-top -->
		</footer><!-- #colophon -->
	</div>
</div><!-- #page -->

		  <script type="text/javascript">
			jQuery( document ).ready( function( $ ){
			  if ( $( window ).width() >= 767 ){
				$( '.navbar-nav > li.menu-item > a' ).click( function(){
					if( $( this ).attr('target') !== '_blank' ){
						window.location = $( this ).attr( 'href' );
					}
				});
			  }
			});
		  </script>
		<script type='text/javascript'>
/* <![CDATA[ */
var frontend_ajax_object = {"ajax_url":"http:\/\/www.scullcom.uk\/wp-admin\/admin-ajax.php","ajax_nonce":"0d3408070d"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-content/plugins/accesspress-social-share/js/frontend.js?ver=4.3.5'></script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-content/themes/sparkling/assets/js/skip-link-focus-fix.min.js?ver=20140222'></script>
<script type='text/javascript' src='http://www.scullcom.uk/wp-includes/js/wp-embed.min.js?ver=4.9.3'></script>

</body>
</html>
