## Library Contents
This library contains footprints (.kicad_mod files) for SoM (System on Module), typically functional modules integrated onto a separate PCB
