## :warning: 301 Moved Permanently
Location: https://gitlab.com/kicad/libraries/kicad-symbols
